﻿using System;

namespace WebBrowser.Data
{
    public class Class1
    {
    }
}
